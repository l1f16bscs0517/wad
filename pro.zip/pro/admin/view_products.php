<div class="row">
    <div class="col-sm-12">
        <h1>Products</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Machine Name</th>
                <th scope="col">Machine Modle</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $get_pro = "select * from machine";
            $run_pro = mysqli_query($con,$get_pro);
            $count_pro = mysqli_num_rows($run_pro);
            if($count_pro==0){
                echo "<h2> No Product found in selected criteria </h2>";
            }
            else {
                $i = 0;
                while ($row_pro = mysqli_fetch_row($run_pro)) {
                    
                    $part_num = $row_pro['3'];
                    $quantity = $row_pro['6'];
                    $pro_brand = $row_pro['4'];
                    $pro_price = $row_pro['7'];
                    $modle = $row_pro['5'];
                    $rack = $row_pro['0'];
                    $box = $row_pro['1'];
                    $partname = $row_pro['2'];
                    $product_ID = $row_pro['8'];
                    
                    
                    ?>
                    <tr>
                        <th scope="row"><?php echo ++$i; ?></th>
                        <td><?php echo $partname; ?></td>
                        <td><?php echo $pro_brand; ?> </td>
                        <td><?php echo $modle; ?> </td>
                        <td><?php echo "Rs."." ". $pro_price; ?>/-</td>
                        <td><?php echo $quantity; ?>/-</td>
                        
                        <td><a href="index.php?edit_pro=<?php echo $product_ID?>" class="btn btn-primary">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="index.php?del_pro=<?php echo $product_ID?>" class="btn btn-danger">
                                <i class="fa fa-trash-alt"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</div>