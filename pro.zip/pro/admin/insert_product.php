<?php
if(!isset($_SESSION['user_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}

if(isset($_POST['insert_pro'])){
    //getting text data from the fields
    $part_num = $_POST['part_num'];
    $quantity = $_POST['quantity'];
    $pro_brand = $_POST['pro_brand'];
    $pro_price = $_POST['pro_price'];
    $modle = $_POST['modle'];
    $rack = $_POST['rack'];
    $box = $_POST['box'];
    $partname = $_POST['partname'];


 
    $insert_product = "INSERT INTO `machine`(`rack_No`, `box_No`, `part_Name`, `part_Number`, `machine_Name`, `modle`, `quantity`, `price`) VALUES ('$rack','$box','$partname','$part_num','$pro_brand','$modle','$quantity','$pro_price')";


    $insert_pro = mysqli_query($con, $insert_product);
    if($insert_pro){
        header("location: ".$_SERVER['PHP_SELF']);
    }
}
?>
<h1 class="text-center my-4"><i class="fas fa-plus fa-md"></i> <span class="d-none d-sm-inline"> Add New </span> Product </h1>
<form action="" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="part_num" class="float-md-right"> <span class="d-sm-none d-md-inline"> Part Number </span> </label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-file-signature"></i></div>
                </div>
                <input type="text" class="form-control" id="part_num" name="part_num" placeholder="Enter Part Number" >
            </div>
        </div>
     
     
    </div>
    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="pro_brand" class="float-md-right"> <span class="d-sm-none d-md-inline"> Machine </span> Name</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-stamp"></i></div>
                </div>
                <select class="form-control" id="pro_brand" name="pro_brand">
                    <option>Select Brand</option>
                    <?php
                    $getBrandsQuery = "select * from brands";
                    $getBrandsResult = mysqli_query($con,$getBrandsQuery);
                    while($row = mysqli_fetch_assoc($getBrandsResult)){
                        $brand_id = $row['brand_id'];
                        $brand_title = $row['brand_title'];
                        echo "<option value='$brand_id'>$brand_title</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
      
    </div>
    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="pro_price" class="float-md-right"> <span class="d-sm-none d-md-inline"> </span> Price:</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-money-bill"></i></div>
                </div>
                <input class="form-control" id="pro_price" name="pro_price" placeholder="Enter Product Price">
            </div>
        </div>
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="pro_kw" class="float-md-right"><span class="d-sm-none d-md-inline"> Part </span> Name</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4 mt-3 mt-lg-0">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-key"></i></div>
                </div>
                <input class="form-control" type="text" id="partname" name="partname" placeholder="Enter part name">
            </div>
        </div>
    </div>

    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="quantity" class="float-md-right"><span class="d-sm-none d-md-inline"> Quantity </span> </label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="far fa-comment-alt"></i></div>
                </div>
                <textarea class="form-control" type="file" id="quantity" name="quantity" placeholder="Enter Product quantity"></textarea>
            </div>
        </div>
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="modle" class="float-md-right"><span class="d-sm-none d-md-inline"> Machine </span> Modle</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <br>
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-key"></i></div>
                </div>
                <input class="form-control" type="text" id="modle" name="modle" placeholder="Enter Machine modle">
            </div>
        </div>
    </div>

    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="rack" class="float-md-right"><span class="d-sm-none d-md-inline"> Rack Number </span> </label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="far fa-comment-alt"></i></div>
                </div>
                <textarea class="form-control" type="file" id="rack" name="rack" placeholder="Enter rack no"></textarea>
            </div>
        </div>
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="box" class="float-md-right"><span class="d-sm-none d-md-inline"> Box </span>  Number</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <br>
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-key"></i></div>
                </div>
                <input class="form-control" type="text" id="box" name="box" placeholder="Enter box no">
            </div>
        </div>
    </div>

    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto"></div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <button type="submit" name="insert_pro" class="btn btn-primary btn-block"><i class="fas fa-plus"></i> Insert Now </button>
        </div>
    </div>
</form>

