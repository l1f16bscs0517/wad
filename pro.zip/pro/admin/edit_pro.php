<?php
if(!isset($_SESSION['user_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}
if(isset($_GET['edit_pro'])){
    $get_id = $_GET['edit_pro'];
    $get_pro = "select * from machine where product_ID='$get_id'";
    $run_pro = mysqli_query($con, $get_pro);
    $row_pro = mysqli_fetch_array($run_pro);
    $part_num = $row_pro['3'];
    $quantity = $row_pro['6'];
    $pro_brand = $row_pro['4'];
    $pro_price = $row_pro['7'];
    $modle = $row_pro['5'];
    $rack = $row_pro['0'];
    $box = $row_pro['1'];
    $partname = $row_pro['2'];
    $product_ID = $row_pro['8'];

    /*$get_cat = "select * from machineName where m_id = '$pro_brand'";
    $run_cat = mysqli_query($con,$get_cat);
    $row_cat = mysqli_fetch_array($run_cat);
    $Machinename = $row_cat['name'];*/

}
if(isset($_POST['update_pro'])){
    //getting text data from the fields

   // $part_num = $_POST['part_num'];
    $quantity = $_POST['quantity'];
   // $pro_brand = $_POST['pro_brand'];
   // $pro_price = $_POST['pro_price'];
   // $modle = $_POST['modle'];
    $rack = $_POST['rack'];
    $box = $_POST['box'];
    //$partname = $_POST['partname'];
    

    $update_product = "update machine set rack_no = '$rack', 
                                        box_no = '$box',
                                        quantity = quantity + '$quantity'
                                        where product_ID='$product_ID'";

    $update_pro = mysqli_query($con, $update_product);
    if($update_pro){
        header("location: index.php?view_products");
    }
}
?>
<div class="row">
    <div class="offset-md-2 col-md-8">
        <form action="" method="post" enctype="multipart/form-data">
           
    

    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="quantity" class="float-md-right"><span class="d-sm-none d-md-inline"> Quantity </span> </label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="far fa-comment-alt"></i></div>
                </div>
                <textarea class="form-control" type="file" id="quantity" name="quantity" placeholder="Enter Product quantity"></textarea>
            </div>
        </div>
       

    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="rack" class="float-md-right"><span class="d-sm-none d-md-inline"> Rack Number </span> </label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="far fa-comment-alt"></i></div>
                </div>
                <textarea class="form-control" type="file" id="rack" name="rack" placeholder="Enter rack no"></textarea>
            </div>
        </div>

        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="box" class="float-md-right"><span class="d-sm-none d-md-inline"> Box </span>  Number</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <br>
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-key"></i></div>
                </div>
                <input class="form-control" type="text" id="box" name="box" placeholder="Enter box no">
            </div>
        </div>
    </div>



        <div class="col-lg-12">
            <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto"></div>
            <div class="form-group row">
                <div class="offset-sm-3 col-12 col-sm-6">
                    <input class="btn btn-block btn-primary btn-lg" type="submit" id="update_pro" name="update_pro"
                           value="Update Product Now">
                </div>
            </div>
        </div>
        </form>
    </div>
</div>
